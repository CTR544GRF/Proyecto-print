sudo python sgfplibtest.py
