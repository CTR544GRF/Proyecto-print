sudo python autoon.py
