javac -deprecation -classpath ".:AbsoluteLayout.jar:FDxSDKPro.jar" SecuGen/FDxSDKPro/samples/*.java
#/usr/lib/jvm/java-6-openjdk/bin/javac -deprecation -classpath ".:AbsoluteLayout.jar:FDxSDKPro.jar" SecuGen/FDxSDKPro/samples/*.java
